//
//  LeaderBoardViewController.swift
//  TicTacToeMidtermProject
//
//  Created by Izzy Geller on 3/20/19.
//  Copyright © 2019 Isabelle Geller. All rights reserved.
//

import UIKit

class LeaderBoardViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
